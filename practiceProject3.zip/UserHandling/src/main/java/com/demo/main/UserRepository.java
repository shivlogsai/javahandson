package com.demo.main;

import org.springframework.data.repository.CrudRepository;

import com.demo.main.User;




public interface UserRepository extends CrudRepository<User, Integer> {

    public User findByName(String name);
}