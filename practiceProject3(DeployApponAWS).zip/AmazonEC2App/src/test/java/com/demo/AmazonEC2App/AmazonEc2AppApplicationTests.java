package com.demo.AmazonEC2App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonEc2AppApplicationTests {

	@Test
	void contextLoads() {
	}

}
