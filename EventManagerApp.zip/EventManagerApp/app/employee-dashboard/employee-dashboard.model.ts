export class EmployeeModel{
    id:number=0;
    first_name:string="";
    last_name:string="";
    email:string="";
}